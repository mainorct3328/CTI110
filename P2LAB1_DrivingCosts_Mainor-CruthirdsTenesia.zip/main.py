m_p_g = float(input())
c_p_g = float(input())


print('{:.2f} {:.2f} {:.2f}'.format (( 20/m_p_g)*c_p_g ,  ( 75/m_p_g)*c_p_g ,  ( 500/m_p_g)*c_p_g))

m_p_g = float(input())
c_p_g = float(input())

print('{:.2f} {:.2f} {:.2f}'.format (( 20/m_p_g)*c_p_g, ( 75/m_p_g)*c_p_g,    ( 500/m_p_g )*c_p_g))  

