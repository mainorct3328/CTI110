current_price = int(input())
last_months_price = int(input())
change_in_price = current_price - last_months_price
estimated_mortgage = int(current_price * 0.051) / 12


''' Type your code here. '''

print('This house is $' + ('{:.0f}'.format(current_price)) + '.' ' The change is $' + ('{:.0f}'.format(change_in_price)) + ' since last month.')
print('The estimated monthly mortgage is $' + ('{:.2f}'.format(estimated_mortgage)) + '.')

current_price = int(input())
last_months_price = int(input())
change_in_price = current_price - last_months_price
estimated_mortgage = int(current_price * 0.051) / 12


''' Type your code here. '''

print('This house is $' + ('{:.0f}'.format(current_price)) + '.' ' The change is $' + ('{:.0f}'.format(change_in_price)) + ' since last month.')
print('The estimated monthly mortgage is $' + ('{:.2f}'.format(estimated_mortgage)) + '.')

current_price = int(input())
last_months_price = int(input())
change_in_price = current_price - last_months_price
estimated_mortgage = int(current_price * 0.051) / 12


''' Type your code here. '''

print('This house is $' + ('{:.0f}'.format(current_price)) + '.' ' The change is $' + ('{:.0f}'.format(change_in_price)) + ' since last month.')
print('The estimated monthly mortgage is $' + ('{:.2f}'.format(estimated_mortgage)) + '.')